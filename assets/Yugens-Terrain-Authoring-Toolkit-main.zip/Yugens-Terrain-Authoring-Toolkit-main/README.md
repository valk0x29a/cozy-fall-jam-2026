# Yūgen's Terrain Authoring Toolkit
The public version of the Marching Squares Terrain plugin for godot.

This project is an effort to create a simple to use and powerfull terrain authoring tool inside godot aimed at level based small to medium sized stylized 3d games. However, the plugin featured in this project can be used for a wide variety of games and experimentation is encouraged! As of right now the plugin has the following features:

* Elevate and lower terrain based on cells in a chunk grid
* Level terrain to a user-set height
* Smooth terrain depending on the average height of neighbouring cells
* Create a bridge between two points by drawing a line between them
* Paint up to 15(+1) custom textures onto the terrain
* Paint a mask map that determines whether selected cells should draw `MultiMeshInstance3d` grass instances
* Get debug information for selected cells
* Change the internal marching squares algorithm vertex merge threshold value resulting in smoother or blockier terrain
* Change global terrain settings like the default wall texture, texture blend mode, grass animation fps and more...

For more in-depth documentation, please refer to the _documentation_ folder in the addon.

For community showcases, feature requests and bug reporting, please refer to the [discord](https://discord.gg/ZSeYkTCgft).
A bug can also be reported by opening a new issue thread in the issues tab of this github project.

## Install Guide

To install the plugin, simply download or clone the latest stable version of this project and copy the plugin from this project's addon folder into your own. Make sure to turn on the plugin in godot by going into the project settings and under "plugins" checking the checkbox next to the plugin's name.

Watch the [YouTube](https://www.youtube.com/playlist?list=PLXcmz5ZRdiyTpf_Jk9gGNb9QQ6Hus8xiP) videos to get started with the plugin!!!

## Known Issues

1. Smooth texture blending breaks at certain elevated/lowered cell edge cases
2. d3d12 doesn't load terrain material properly when in game on some devices -> set the renderer to vulkan for the time being if possible on your device
3. Some maps turn black or white in game

## Supported Pipelines

As of right now the plugin only supports `Forward+` and limited `Compatibility` rendering with both `Mobile` and `Web` rendering not supported.

Which one you should use is dependent on your personal project but also your GPU as some GPU's work better with `Forward+` than `Compatibility`.

## PR Workflow

Please target and base your PR's on `public-testing` instead of `main` otherwise we cannot review or aprove them!

Also make sure to give a good description of what your PR fixes or adds so we don't have to go through all the files unnecessarily.

## Credits

Developed by [Yūgen](https://www.youtube.com/@yugen_seishin) and originally forked from [Jackachulian](https://github.com/jackachulian/jackachulian) on github.

Collaborators (v1.1.0 ONWARDS):
* [DanTrz](https://github.com/DanTrz)
* [powertomato](https://github.com/powertomato)
* [santarl](https://github.com/santarl)

A special thanks to DanTrz (creator of the TileMapLayer3D plugin), powertomato and santarl for co-authoring big parts of the plugin since the 1.0 release. They have been amazing contributors to the project and awesome people to work with!

Contributors:
* [Dylearn](https://www.youtube.com/@Dylearn)
* [AtSaturn](https://www.youtube.com/@AtPlayerSaturn)
* My lifelong best friends!

###
A big thanks to the above people for giving helpful insights, discussing certain features and thinking together about math related problems. Without them I couldn't have finished the plugin as fast as I have.
